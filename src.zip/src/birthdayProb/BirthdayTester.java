package birthdayProb;

public class BirthdayTester {
	
	public static void main(String args[]) {
		BirthdayProbability statistics = new BirthdayProbability();
		System.out.println(statistics.sharingBirthdayProbability(23,10000));
	}
}
